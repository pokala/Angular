import { Component, OnInit } from '@angular/core';
import { CardetailsService } from '../../services/cardetails.service';

@Component({
  selector: 'app-cardetails',
  templateUrl: './cardetails.component.html',
  styleUrls: ['./cardetails.component.css']
})
export class CardetailsComponent implements OnInit {

  public carsInfo;
  public selectedCars = [];

  constructor(private carInfo: CardetailsService) { }

  ngOnInit() {
    this.carInfo.searchPhotos().subscribe(data => {
     this.carsInfo = data.results;
     console.log( this.carsInfo);
    });
  }

  public onSelect(event, carData) {
    if (event.target.checked) {
      this.selectedCars.push(carData);
    } else {
      this.selectedCars = this.selectedCars.filter( car => {
        return car.id !== carData.id;
      })
    }
  }

}
