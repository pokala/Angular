import { Inject, Injectable, InjectionToken } from '@angular/core';
import { HttpClient, HttpHeaders } from '@angular/common/http';
import { Observable } from 'rxjs';

@Injectable({
  providedIn: 'root'
})

export class CardetailsService {


  constructor(private http: HttpClient) { }

  private get headers(): HttpHeaders {
    return new HttpHeaders({
      Authorization : `Client-ID HqZe8lyf0aqtApOJxQhGnN204TD1EWb-L-O-mSkpczM`
    });
  }

  public searchPhotos(): Observable<any> {
    const url = `https://api.unsplash.com/search/photos?page=1&query=car`;
    return this.http.get(url , { headers: this.headers });
  }
}
