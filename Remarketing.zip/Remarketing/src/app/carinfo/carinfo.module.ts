import { NgModule } from '@angular/core';
import { CommonModule } from '@angular/common';
import { CardetailsComponent } from './components/cardetails/cardetails.component';
import { HttpClientModule } from '@angular/common/http';



@NgModule({
  declarations: [CardetailsComponent],
  imports: [
    CommonModule,
    HttpClientModule
  ]
})
export class CarinfoModule { }
